#============================================================
# PROGRAMMER:........ William H. Weiskopf
# USERID:............ WWEISKOP
# COURSE:............ CSCI-410
# TERM............... FALL 2013
# ASIGNMENT:......... PY03
# FILENAME:.......... py03.py
# PYTHON VERSION:.... 3.3.0
#============================================================


from CS410_inst_py import hack2xml
from asm import asm
from instruction import *

# MAIN
hack2xml('machine.hack', 'machine.xml')
assembly = asm('machine.xml', 'assembly.asm')
print(assembly)
assembly.write()
