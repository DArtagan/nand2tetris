#============================================================
# PROGRAMMER:........ William H. Weiskopf
# USERID:............ WWEISKOP
# COURSE:............ CSCI-410
# TERM............... FALL 2013
# ASIGNMENT:......... ECS 10
# FILENAME:.......... compilation_engine.py
# PYTHON VERSION:.... 3.3.0
#============================================================
class Grammarizer:
    token_pointer = 0
    xml = [ ]

    def __init__(self, tokens):
        self.tokens = tokens
        self.parser(self.tokens)

    def write(self, out_file):
        out = open(out_file, 'w')
        for token in self.xml:
            out.write(str(token) + '\n')


    def parser(self):
        while self.token_pointer < self.tokens.size():
            if (token.flavour() == 'keyword') & (token.value() == 'class'):
                parse_class()
            elif token.flavour() == 'identifier':
                parse_identifier(token.value())

    def parse_class(self):
        xml += '<class>'
        self.parser(self.tokens[self.token_pointer:])
        xml += '</class>'

    def parse_identifier(self, value):
        xml += '<identifier> {0} </identifier>'.format(value) 
